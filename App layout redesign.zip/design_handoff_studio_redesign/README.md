# Handoff: Radiant Pipsqueak — clean / minimal layout redesign

## Overview
A visual + layout redesign of the Radiant Pipsqueak desktop app (Tauri + React + TypeScript).
The goal was to replace the current sci-fi/cosmic theme (deep navy, starfield, glows, Orbitron
type) with a **calm, light, editorial reading-tool aesthetic**, and to fix three specific
complaints: too visually busy, cramped composer + feed, and too much chrome/decoration.

The redesign keeps **all existing functionality and Tauri command wiring** — only the layout,
structure, and styling change. No backend (`src-tauri`) changes are required.

## About the Design Files
The file in this bundle (`Radiant Pipsqueak.dc.html`) is a **design reference created in HTML** —
a working prototype showing the intended look, layout, and interaction behavior. It is **not
production code to copy directly**.

The task is to **recreate this design inside the existing codebase** — i.e. rewrite
`src/App.tsx` markup + `src/App.css` (or migrate to CSS modules if you prefer) so the real app
matches this prototype, while preserving every existing `invoke(...)` call, state variable, and
data flow already present in `App.tsx`. Do not ship the HTML file itself.

> Note: the prototype simulates audio playback and usage numbers locally so the design is
> explorable in a browser. In the real app these must stay wired to the existing Tauri commands
> (see **State Management** below) — the prototype's fake timers/estimates are illustrative only.

## Fidelity
**High-fidelity.** Final colors, typography, spacing, radii, and interaction states are all
specified below and should be reproduced closely. Where the prototype differs from the current
app's information architecture, the prototype wins (that is the redesign).

---

## Design language (apply globally)

- **Surface / paper background:** `#efece5` (app window backdrop, behind panels)
- **Primary panel surface:** `#faf8f3`
- **Secondary / right-pane surface:** `#f6f3ec`
- **Toolbar / sidebar surface:** `#f5f2ea`
- **Card surface:** `#ffffff`
- **Hairline borders:** `#e3ddd1` (structural), `#eee7db` / `#ece7dc` (soft), `#e0dacd` (inputs)
- **Ink:** `#221f19` (headings), `#2b2721` (primary), `#3a352d` / `#332f28` (body),
  `#6f695d` (secondary), `#8b857a` (muted), `#a29b8c` (labels), `#b6af9f` (faint)
- **Accent (terracotta):** `#c2703d`; darker accent text `#8f4a20`; soft accent chip `#efe7db`
  - The accent is a **theme variable** — implement it as a CSS custom property `--accent`
    (default `#c2703d`) so it can be re-themed. The prototype exposes it as a tweak.
- **Positive dot:** `#5b9a6f` (key-connected indicator)

### Typography
- **UI / chrome:** `Libre Franklin` (Google Font), weights 400/500/600/700.
- **Reading text** (session title, manuscript textarea, reading-direction, readback paragraphs,
  panel headings): `Newsreader` (Google Font), 400/500, plus 400 italic. Exposed as a
  `--read-font` variable so a "serif reading" toggle can swap it to Libre Franklin.
- **Numeric / mono option:** `IBM Plex Mono` (loaded, used for tabular figures if desired).
- Tabular numbers: use `font-variant-numeric: tabular-nums` on time/cost/char figures.
- Uppercase micro-labels: `11px`, `font-weight:600`, `letter-spacing:0.10–0.13em`,
  `text-transform:uppercase`, color `#a29b8c`.

### Shape & elevation
- Window/panel radius: `14px`; cards: `13–14px`; inputs: `10–11px`; pills/buttons: `999px`.
- Soft shadow for floating window/menus only:
  `0 24px 60px -30px rgba(60,50,30,0.28)` (window),
  `0 16px 40px -18px rgba(60,50,30,0.4)` (dropdown menus).
- Everything else is flat with hairline borders — **no glows, no gradients, no starfield.**
  Remove `.star-map`, the `.app-shell::before/::after` decoration, and all `box-shadow` glow
  effects from the current `App.css`.

---

## Screens / Views

### 1. App shell / toolbar (persistent)
- **Layout:** full-height flex column. Top toolbar (fixed height ~56px) + body below.
- **Toolbar** (`#f5f2ea`, bottom border `#e3ddd1`, padding `14px 24px`, `display:flex; gap:18px; align-items:center`):
  - **Left — wordmark:** 26px circle, `1.5px solid var(--accent)` ring enclosing an 8px accent
    dot; label "Radiant Pipsqueak" at `15px/600`, letter-spacing `-0.01em`.
  - **Segmented tabs** (Studio / Usage): container `#e9e2d5`, radius 999px, 3px padding.
    Active tab: `#fff` bg, `#2b2721` text, 600. Idle: transparent, `#7c766a`.
    Buttons `padding:6px 16px`, `13px/600`.
  - **Spacer** (`flex:1`).
  - **Studio-only, right group** (hidden on Usage tab): Voice pill, Model pill, Generate button.
    - Pills: white bg, `1px solid #e0dacd`, radius 999px, `padding:7px 13px`. Content:
      uppercase micro-label ("VOICE"/"MODEL") + value at `13px/500` + `▾` chevron `#bdb6a7`.
      Clicking opens a dropdown menu (see Interactions).
    - Generate button: `var(--accent)` bg, white, `13.5px/600`, `padding:9px 22px`, radius 999px.

### 2. Studio tab (default)
Two-column grid filling the body: `grid-template-columns: 1fr 1fr`.

**Left pane — editor** (`#faf8f3`, right border `#e3ddd1`, `padding:30px 36px`, scrollable):
- **Header row** (`space-between`, margin-bottom 22px):
  - **Session switcher:** a text button "SESSION ▾" (uppercase micro-label + chevron). Opens a
    280px dropdown listing all sessions (title `13.5px/500`, meta `"<n> readbacks"` `11.5px`
    `#a29b8c`; active row bg `#f4ede2`), a hairline, then a "+ New session" action in accent.
  - **Estimate:** right-aligned `12.5px #8b857a`, format `"257 chars · ~$0.0002"` (live from
    manuscript length × model rate).
  - **Title input:** borderless, transparent, `Newsreader 30px/500`, ink `#221f19`,
    placeholder "Untitled session". Bound to session title.
  - **Manuscript textarea:** borderless, transparent, `Newsreader 16.5px`, line-height 1.72,
    color `#3a352d`, min-height ~280px, no resize. Placeholder explains blank-line = paragraph.
  - **Reading direction box:** `1px dashed #e0dacd`, bg `#f7f3ec`, radius 12px, padding 16/18.
    Micro-label "READING DIRECTION" + borderless italic `Newsreader 14px` textarea.

**Right pane — readback** (`#f6f3ec`, flex column):
- **Header row:** micro-label "READBACK" left; paragraph count (`"2 paragraphs"`) right.
- **Empty state** (no paragraphs): dashed card, `Newsreader 18px` "Nothing to read yet" +
  helper line.
- **Paragraph cards** (one per manuscript paragraph, derived live by splitting on blank lines):
  white, `1px solid #eee7db`, radius 14px, `padding:18px 20px`, gap 14px between cards.
  - Header: "PARAGRAPH n" micro-label (`#b6af9f`) + right meta (`"0:09"` duration when
    generated, else `"not generated"`).
  - Body text: `Newsreader 15.5px`, line-height 1.7, `#332f28`.
  - **If generated:** a control row — round accent Play/Pause button (32px, `▶` / `❙❙`),
    a 4px progress track (`#eee7db` with `var(--accent)` fill), tabular time label
    `"0:07 / 0:18"`, and a 30px outlined "↻" regenerate button.
  - **If not generated:** a full-width "Generate readback" button (`1px solid #e4ded1`,
    bg `#faf7f1`, accent-dark text `#8f4a20`, `13px/600`, radius 9px).
- **Voice-test footer** (sticks to bottom of right pane, top border `#e3ddd1`, `padding:14px 34px`):
  a white pill (`1px solid #e6e0d3`, radius 999px) containing micro-label "VOICE TEST",
  a borderless input, and a soft-chip "Preview" button (`#efe7db` bg, `#8f4a20` text). While
  previewing, label reads "Playing…".

### 3. Usage tab
Scrollable, `max-width:1000px` centered, `grid-template-columns:1fr 1fr; gap:22px; align-items:start`.

- **Left column:**
  - **Usage snapshot:** `Newsreader 22px/500` heading + muted subline. 2×2 metric card grid:
    Generations, Characters, Est. tokens, Est. spend. Each card: white, `1px solid #eee7db`,
    radius 13px, padding 16/18; micro-label + big `26px/600` value (Est. spend value in accent).
  - **Model rates:** micro-label + white bordered list; each row `model` left, `"$0.60 / 1M chars"`
    right (`13px/500`, tabular), rows split by `#f2ece1` hairline.
  - **Last 4 days:** micro-label + white bordered list; 3-col rows (date, chars, cost).
- **Right column — Usage & settings panel:** white card, `1px solid #eee7db`, radius 16px,
  padding 26. `Newsreader 22px/500` heading. Fields (label = uppercase micro-label):
  - Monthly budget (USD) — number input.
  - Monthly character limit — number input.
  - Hard-stop checkbox (`accent-color: var(--accent)`) + label.
  - Default reading direction — italic `Newsreader` textarea.
  - Save button (accent, full width); shows "Saved ✓" for 1.5s after click.
  - Footer row: "API key — Connected · stored locally" + outlined "Replace key" button
    (returns to onboarding).
  - Inputs: bg `#faf8f3`, `1px solid #e0dacd`, radius 10px, padding 10/12.

### 4. Onboarding / API key (shown when not configured)
Centered card on `#efece5`, width 480px, bg `#faf8f3`, `1px solid #e3ddd1`, radius 18px,
padding 38/40, soft shadow. Contents: wordmark, `Newsreader 27px/500` headline "Bring your own
voice.", muted explainer, "OPENAI API KEY" label, password input (placeholder `sk-...`),
"Need a key? Create one on OpenAI." link, full-width accent "Save and continue" button.

---

## Interactions & Behavior
- **Tab switch:** Studio ⇄ Usage; right-side toolbar controls only show on Studio.
- **Voice / Model / Session dropdowns:** click pill/switcher to toggle a floating menu
  (absolute, z-index above content). A full-screen transparent backdrop closes any open menu on
  outside click. Selecting an option updates the active session's voice/model and closes.
- **Live paragraph breakup:** the readback list is derived from the manuscript by splitting on
  `\n\s*\n+` — editing the manuscript updates cards immediately. Editing a paragraph makes it
  "not generated" again (stale), matching real regeneration semantics.
- **Generate (per paragraph & Generate-all):** marks paragraph(s) as generated → in the real app
  this calls the existing `generate_audio` / audio pipeline.
- **Play/pause:** one paragraph plays at a time; progress fills the track; toggling stops it.
  In production, drive a real `<audio>` element from the data URL returned by
  `get_audio_data_url`.
- **Voice test:** "Preview" → in production call `generate_voice_preview`.
- **Save settings:** brief "Saved ✓" confirmation.
- **Replace key / onboarding:** returns to the API-key screen.
- **Transitions:** keep them minimal — subtle opacity/position only. No large motion; this is a
  calm tool.

## State Management (keep the existing App.tsx wiring)
The current `App.tsx` already owns this state and these Tauri commands — reuse them; only the
markup around them changes:
- `get_setup_status` → configured flag (onboarding vs app).
- `save_api_key` → onboarding save.
- `list_snippets` → sessions list + selection (`selectedSnippetId`, `title`, `content`).
- `estimate_generation` (on `content`/`model` change) → the live char/cost estimate.
- `generate_audio` (with `snippetId`, `title`, `content`, `voice`, `model`,
  `readingInstructions`, `forceRegenerate`) → generate / regenerate.
- `get_audio_data_url` → playback source.
- `generate_voice_preview` → voice test.
- `get_usage_summary`, `get_usage_settings`, `save_usage_settings`, `get_usage_timeline`,
  `get_usage_limit_status` → Usage tab.
- Local UI state to add: `openMenu` (`'voice' | 'model' | 'session' | null`) for dropdowns,
  and per-paragraph play/progress state.

> The current design derives per-paragraph cards from `splitParagraphs(content)` — keep that.
> The main IA change: paragraphs move from a passive "session feed" into the **right pane as the
> primary readback surface**, each with its own generate/play controls.

## Design Tokens (summary)
- Colors: see **Design language** above.
- Spacing: 4 / 6 / 8 / 10 / 12 / 14 / 16 / 18 / 20 / 22 / 26 / 30 / 34 / 36 px.
- Radius: 9 (small) / 10–11 (inputs) / 13–14 (cards, window) / 16–18 (settings, onboarding) / 999 (pills).
- Type scale: 11 (micro-label) / 12.5–13.5 (meta/controls) / 14–16.5 (body/reading) / 22 (panel h) /
  26 (metric value) / 27–30 (titles/headline).
- Shadows: `0 24px 60px -30px rgba(60,50,30,0.28)` (window), `0 16px 40px -18px rgba(60,50,30,0.4)` (menu).

## Assets
- **Fonts:** Google Fonts — Libre Franklin, Newsreader, IBM Plex Mono. Add the `<link>` (or
  self-host) in `index.html`.
- **No image assets.** The wordmark is a pure-CSS ring + dot (no SVG needed). The old
  `public/tauri.svg` / `vite.svg` and starfield are unused by the new design.
- **Icons:** simple text glyphs (`▶`, `❙❙`, `↻`, `▾`, `+`). Swap for an icon set (e.g. Lucide)
  if the codebase already has one.

## Files
- `Radiant Pipsqueak.dc.html` — the high-fidelity interactive design reference (this bundle).
  Open it in a browser to explore layout, spacing, and interaction behavior. It is a self-contained
  prototype; treat its structure/values as the spec, not its runtime code.
- Target files to change in the repo: `src/App.tsx` (markup + local UI state) and `src/App.css`
  (replace the theme wholesale). No `src-tauri` changes.
